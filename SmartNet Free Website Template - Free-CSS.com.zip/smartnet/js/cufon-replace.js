Cufon.replace('#faded ul.slides li a, header nav li, .link1, .link3, .link4', { fontFamily: 'Myriad Pro Regular', textShadow: '#000 1px 1px', hover:true });
Cufon.replace('.link2', { fontFamily: 'Myriad Pro Regular', textShadow: '#265800 1px 1px', hover:{textShadow: 'none'} });
Cufon.replace('h1', { fontFamily: 'Myriad Pro Regular', textShadow: '#000 1px 1px', color: '-linear-gradient(#82b704, #699303)' });
Cufon.replace('h1 span', { fontFamily: 'Myriad Pro Regular', color: '-linear-gradient(#fff, #cdcdcd)' });
Cufon.replace('#faded ul.pagination li a span, h2', { fontFamily: 'Myriad Pro Light' });
Cufon.replace('h3, h4, .banners li a', { fontFamily: 'Myriad Pro Light', textShadow: '#417c01 1px 1px' });
Cufon.replace('.banners li a b', { fontFamily: 'Myriad Pro Semibold', textShadow: '#417c01 1px 1px' });
Cufon.replace('.price', { fontFamily: 'Myriad Pro Regular', color: '-linear-gradient(#7fb504, #488801)' });
Cufon.replace('#slogan h2', { fontFamily: 'Myriad Pro Regular' });